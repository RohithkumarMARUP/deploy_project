# DEPLOYING THE REGRESSION MODEL FOR AN REAL_ESTATE BUSSINESS PROBLEM

Please note that the project segemnts are of a collabration of many department so in case of 
deployement issues get back to us and also solve through (https://www.google.com).
let's work on it
to the whole work